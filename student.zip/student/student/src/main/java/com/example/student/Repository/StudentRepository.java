package com.example.student.Repository;

import com.example.student.Models.StudentApp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<StudentApp,Long> {
}
